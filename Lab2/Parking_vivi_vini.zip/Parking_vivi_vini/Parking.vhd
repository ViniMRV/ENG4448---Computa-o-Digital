
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity Parking is
    Port ( clk : in  STD_LOGIC;
           reset : in  STD_LOGIC;
           a : in  STD_LOGIC;
           b : in  STD_LOGIC;
           z : out  STD_LOGIC_VECTOR (7 downto 0));
end Parking;

architecture Behavioral of Parking is
	type state_type is (idle, e1, e2, e3, s1, s2, s3);
	signal state_reg, state_next : state_type := idle;
	signal z_reg : STD_LOGIC_VECTOR (7 downto 0) := (4 => '1', others => '0');
	signal entrando, saindo : STD_LOGIC := '0';
begin

	z <= z_reg;
	
-- state register
	process(clk, reset)
	begin
		if reset = '1' then
			state_reg <= idle;
			z_reg <= (others => '0');
		elsif (clk'event and clk = '1') then
			state_reg <= state_next;
			if (entrando = '1') then
				z_reg <= z_reg(6 downto 0) & '1';
			elsif (saindo = '1') then
				z_reg <= '0' & z_reg(7 downto 1);
			end if;
		end if;
	end process;
-- next state / output logic
	process(state_reg, a, b, reset)
	begin
		state_next <= state_reg;
		entrando <= '0';
		saindo <= '0';
		case state_reg is
			when idle =>
				if a = '1' and b = '0' then
					state_next <= e1;
				elsif a = '0' and b = '1' then
					state_next <= s1;
				end if;
		
		
			when e1 =>
				if a = '1' and b = '1' then
					state_next <= e2;
				elsif a = '0' and b = '0' then
					state_next <= idle;
				end if;
			when e2 =>
				if a = '0' and b = '1' then
					state_next <= e3;
				elsif a = '1' and b = '0' then
					state_next <= e1;
				end if;
			when e3 =>
				if a = '0' and b = '0' then
					state_next <= idle;
					entrando <= '1';
				elsif a = '1' and b = '1' then
					state_next <= e2;
				end if;
				
				
			when s1 =>
				if a = '1' and b = '1' then
					state_next <= s2;
				elsif a = '0' and b = '0' then
					state_next <= idle;
				end if;
			when s2 =>
				if a = '1' and b = '0' then
					state_next <= s3;
				elsif a = '0' and b = '1' then
					state_next <= s1;
				end if;
			when s3 =>
				if a = '0' and b = '0' then
					state_next <= idle;
					saindo <= '1';
				elsif a = '1' and b = '1' then
					state_next <= s2;
				end if;
				
		end case;
	end process;

end Behavioral;

