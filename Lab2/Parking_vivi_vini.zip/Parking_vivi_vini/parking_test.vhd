
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;

ENTITY parking_test IS
END parking_test;
 
ARCHITECTURE behavior OF parking_test IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT Parking
    PORT(
         clk : IN  std_logic;
         reset : IN  std_logic;
         a : IN  std_logic;
         b : IN  std_logic;
         z : OUT  std_logic_vector(7 downto 0)
        );
    END COMPONENT;
    

   --Inputs
   signal clk : std_logic := '0';
   signal reset : std_logic := '0';
   signal a : std_logic := '0';
   signal b : std_logic := '0';

 	--Outputs
   signal z : std_logic_vector(7 downto 0);

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: Parking PORT MAP (
          clk => clk,
          reset => reset,
          a => a,
          b => b,
          z => z
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
	--entrando 5
		for I in 0 to 4 loop
			a<='0';
			b<='0';
			wait for 10 ns;
			a<='1';
			b<='0';
			wait for 10 ns;
			a<='1';
			b<='1';
			wait for 10 ns;
			a<='0';
			b<='1';
			wait for 10 ns;
			a<='0';
			b<='0';
			wait for 10 ns;
		end loop;
		
	--saindo 2	
		for I in 0 to 1 loop
			a<='0';
			b<='0';
			wait for 10 ns;
			a<='0';
			b<='1';
			wait for 10 ns;
			a<='1';
			b<='1';
			wait for 10 ns;
			a<='1';
			b<='0';
			wait for 10 ns;
			a<='0';
			b<='0';
			wait for 10 ns;
		end loop;
		
	--tenta entrar mas desiste
		a<='0';
		b<='0';
		wait for 10 ns;
		a<='1';
		b<='0';
		wait for 10 ns;
		a<='1';
		b<='1';
		wait for 10 ns;
		a<='1';
		b<='0';
		wait for 10 ns;
		a<='0';
		b<='0';
		wait for 10 ns;
		
	--sai 1
		a<='0';
		b<='0';
		wait for 10 ns;
		a<='0';
		b<='1';
		wait for 10 ns;
		a<='1';
		b<='1';
		wait for 10 ns;
		a<='1';
		b<='0';
		wait for 10 ns;
		a<='0';
		b<='0';
		wait for 10 ns;

--entra 1

		a<='0';
		b<='0';
		wait for 10 ns;
		a<='1';
		b<='0';
		wait for 10 ns;
		a<='1';
		b<='1';
		wait for 10 ns;
		a<='0';
		b<='1';
		wait for 10 ns;
		a<='0';
		b<='0';
		wait for 10 ns;
		
      wait;
		
   end process;

END;
